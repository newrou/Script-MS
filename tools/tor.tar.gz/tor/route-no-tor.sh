#!/bin/bash

service tor stop
service tor status

/sbin/modprobe iptable_nat

/sbin/iptables -F
/sbin/iptables -X
/sbin/iptables -t nat -F
/sbin/iptables -t nat -X
/sbin/iptables -t mangle -F
/sbin/iptables -t mangle -X
/sbin/iptables -P INPUT ACCEPT
/sbin/iptables -P FORWARD ACCEPT
/sbin/iptables -P OUTPUT ACCEPT

echo 1 > /proc/sys/net/ipv4/conf/all/forwarding

iptables -L -t nat
netstat -ntulp
